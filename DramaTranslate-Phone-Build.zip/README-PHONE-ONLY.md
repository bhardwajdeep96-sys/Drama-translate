PHONE/TABLET-ONLY BUILD

1. Create a free GitHub account if needed.
2. Create a new repository named DramaTranslate.
3. Upload the contents of this folder to the repository (keep the .github folder).
4. Open the repository's Actions tab.
5. Run "Build DramaTranslate APK".
6. Wait for the workflow to finish.
7. Open the completed workflow run and download the "DramaTranslate-debug" artifact.
8. Extract the artifact and install app-debug.apk on the Android tablet.

No computer or Android Studio is required for this build route.

IMPORTANT:
Android will show security warnings when installing an APK that was not installed
from Google Play. Only install the APK you built from your own GitHub repository.
