package com.dramatranslate;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.hardware.display.*;
import android.media.*;
import android.media.projection.MediaProjection;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.TextView;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions;
import com.google.mlkit.translate.TranslateLanguage;
import com.google.mlkit.translate.Translation;
import com.google.mlkit.translate.Translator;
import com.google.mlkit.translate.TranslatorOptions;

import java.nio.ByteBuffer;
import java.util.concurrent.atomic.AtomicBoolean;

public class TranslationService extends Service {
    private static final String CHANNEL = "translation";
    private MediaProjection projection;
    private ImageReader reader;
    private VirtualDisplay display;
    private TextRecognizer recognizer;
    private Translator translator;
    private HandlerThread workerThread;
    private Handler worker;
    private final AtomicBoolean processing = new AtomicBoolean(false);
    private String lastChinese = "";
    private long lastProcessed = 0;
    private WindowManager wm;
    private TextView overlay;

    @Override public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        Notification n = buildNotification();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(10, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(10, n);
        }

        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        recognizer = TextRecognition.getClient(new ChineseTextRecognizerOptions.Builder().build());

        TranslatorOptions options = new TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.CHINESE)
                .setTargetLanguage(TranslateLanguage.ENGLISH)
                .build();
        translator = Translation.getClient(options);
        translator.downloadModelIfNeeded();

        workerThread = new HandlerThread("ocr-worker");
        workerThread.start();
        worker = new Handler(workerThread.getLooper());
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        int resultCode = intent.getIntExtra("resultCode", Activity.RESULT_CANCELED);
        Intent resultData = intent.getParcelableExtra("resultData");
        if (resultCode == Activity.RESULT_OK && resultData != null && projection == null) {
            startCapture(resultCode, resultData);
        }
        return START_NOT_STICKY;
    }

    private void startCapture(int resultCode, Intent data) {
        projection = ((android.media.projection.MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE))
                .getMediaProjection(resultCode, data);

        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        int width = dm.widthPixels, height = dm.heightPixels, density = dm.densityDpi;
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);

        reader.setOnImageAvailableListener(r -> {
            Image image = r.acquireLatestImage();
            if (image == null) return;
            long now = System.currentTimeMillis();
            if (now - lastProcessed < 400 || !processing.compareAndSet(false, true)) {
                image.close(); return;
            }
            lastProcessed = now;
            worker.post(() -> { try { processImage(image, width, height); }
                                finally { processing.set(false); } });
        }, worker);

        display = projection.createVirtualDisplay("DramaTranslate", width, height, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.getSurface(), null, worker);
    }

    private void processImage(Image image, int width, int height) {
        Bitmap bitmap = null, crop = null;
        try {
            Image.Plane plane = image.getPlanes()[0];
            ByteBuffer buffer = plane.getBuffer();
            int pixelStride = plane.getPixelStride();
            int rowStride = plane.getRowStride();
            int rowPadding = rowStride - pixelStride * width;
            bitmap = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888);
            bitmap.copyPixelsFromBuffer(buffer);

            int top = (int)(height * 0.58f);
            crop = Bitmap.createBitmap(bitmap, 0, top, width, height - top);
            InputImage input = InputImage.fromBitmap(crop, 0);

            recognizer.process(input).addOnSuccessListener(result -> {
                StringBuilder cjk = new StringBuilder();
                for (com.google.mlkit.vision.text.Text.TextBlock block : result.getTextBlocks())
                    for (com.google.mlkit.vision.text.Text.Line line : block.getLines()) {
                        String s = line.getText().trim();
                        if (containsCjk(s)) {
                            if (cjk.length() > 0) cjk.append("\n");
                            cjk.append(s);
                        }
                    }

                String chinese = cjk.toString().trim();
                if (chinese.length() < 2 || chinese.equals(lastChinese)) return;
                lastChinese = chinese;

                translator.translate(chinese)
                        .addOnSuccessListener(this::showSubtitle)
                        .addOnFailureListener(e -> {});
            }).addOnCompleteListener(t -> { if (crop != null && !crop.isRecycled()) crop.recycle(); });
        } catch (Throwable ignored) {
        } finally {
            image.close();
            if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
        }
    }

    private boolean containsCjk(String s) {
        for (int i = 0; i < s.length(); i++) {
            Character.UnicodeBlock b = Character.UnicodeBlock.of(s.charAt(i));
            if (b == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS ||
                b == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_A ||
                b == Character.UnicodeBlock.CJK_COMPATIBILITY_IDEOGRAPHS) return true;
        }
        return false;
    }

    private void showSubtitle(String english) {
        if (english == null || english.trim().isEmpty()) return;
        new Handler(Looper.getMainLooper()).post(() -> {
            if (!Settings.canDrawOverlays(this)) return;
            if (overlay == null) {
                overlay = new TextView(this);
                overlay.setTextColor(Color.WHITE);
                overlay.setTextSize(20);
                overlay.setGravity(Gravity.CENTER);
                overlay.setPadding(28, 12, 28, 12);
                overlay.setBackgroundColor(0xB8000000);
                WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                        WindowManager.LayoutParams.MATCH_PARENT,
                        WindowManager.LayoutParams.WRAP_CONTENT,
                        Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                                : WindowManager.LayoutParams.TYPE_PHONE,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                        PixelFormat.TRANSLUCENT);
                p.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
                p.y = 95;
                wm.addView(overlay, p);
            }
            overlay.setText(english);
            overlay.setVisibility(View.VISIBLE);
            overlay.removeCallbacks(hideOverlay);
            overlay.postDelayed(hideOverlay, 5000);
        });
    }

    private final Runnable hideOverlay = () -> { if (overlay != null) overlay.setVisibility(View.GONE); };

    @Override public void onDestroy() {
        try { if (display != null) display.release(); } catch (Exception ignored) {}
        try { if (projection != null) projection.stop(); } catch (Exception ignored) {}
        try { if (reader != null) reader.close(); } catch (Exception ignored) {}
        try { if (recognizer != null) recognizer.close(); } catch (Exception ignored) {}
        try { if (translator != null) translator.close(); } catch (Exception ignored) {}
        if (workerThread != null) workerThread.quitSafely();
        if (overlay != null) try { wm.removeView(overlay); } catch (Exception ignored) {}
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    private Notification buildNotification() {
        Intent i = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this, CHANNEL)
                .setContentTitle("DramaTranslate")
                .setContentText("Chinese → English translation is running")
                .setSmallIcon(android.R.drawable.ic_menu_search)
                .setContentIntent(pi).setOngoing(true).build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "DramaTranslate",
                    NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }
}
