package com.dramatranslate;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.*;

public class MainActivity extends Activity {
    private static final int REQ_CAPTURE = 7001;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(48, 60, 48, 48);
        root.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView title = new TextView(this);
        title.setText("DramaTranslate");
        title.setTextSize(30);
        title.setTextColor(Color.BLACK);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView info = new TextView(this);
        info.setText("\nChinese drama → Chinese OCR → English subtitle overlay\n\n"
                + "1. Allow 'Display over other apps'.\n"
                + "2. Tap Start translation.\n"
                + "3. Approve Android's screen-capture request.\n"
                + "4. Return to the drama.\n");
        info.setTextSize(16);
        info.setTextColor(Color.DKGRAY);
        root.addView(info, new LinearLayout.LayoutParams(-1, 0, 1));

        Button overlay = new Button(this);
        overlay.setText("Allow overlay");
        overlay.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            } else Toast.makeText(this, "Overlay permission is already enabled.", Toast.LENGTH_SHORT).show();
        });
        root.addView(overlay);

        Button start = new Button(this);
        start.setText("Start translation");
        start.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Enable overlay permission first.", Toast.LENGTH_LONG).show();
                return;
            }
            android.media.projection.MediaProjectionManager m =
                    (android.media.projection.MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
            startActivityForResult(m.createScreenCaptureIntent(), REQ_CAPTURE);
        });
        root.addView(start);

        Button stop = new Button(this);
        stop.setText("Stop translation");
        stop.setOnClickListener(v -> stopService(new Intent(this, TranslationService.class)));
        root.addView(stop);

        setContentView(root);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_CAPTURE && resultCode == RESULT_OK && data != null) {
            Intent s = new Intent(this, TranslationService.class);
            s.putExtra("resultCode", resultCode);
            s.putExtra("resultData", data);
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(s);
            else startService(s);
            Toast.makeText(this, "Translation started.", Toast.LENGTH_SHORT).show();
        }
    }
}
